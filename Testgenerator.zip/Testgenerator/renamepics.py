import os
for pic in os.listdir("Bilder"):
    if pic.endswith(".jpg"):
        os.rename("Bilder" + "/" + pic, "Bilder" + "/" + os.path.splitext(pic)[0] + str(2) + ".jpg")
        print("Bilder" + "/" + pic, "Bilder" + "/" + os.path.splitext(pic)[0] + str(2) + ".jpg")