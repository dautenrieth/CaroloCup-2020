#include<opencv2/opencv.hpp>
#include<fstream>
#include<iostream>
#include<math.h>
#include<string.h>
using namespace std;
using namespace cv;

const int NUMBER_OF_PICTURES = 65;
string PATH = "param.txt";
void readfile();
void write();
Mat drawLines(Mat src, double coefficients[], double coefficients2[], double coefficients3[]);
int IMAGE_HEIGHT = 480, IMAGE_WIDTH = 1280, a = 0;


double coefficients[4] = { 555,0.010,0.00015,-0.000002 };
double coefficients2[4] = { 612,0.010,0.00015,-0.000002 };
double coefficients3[4] = { 670,0.010,0.00015,-0.000002 };
Mat src;
string pictures[NUMBER_OF_PICTURES];

static void on_trackbar(int alpha_slider, void*);
static void on_trackbar1(int alpha_slider1, void*);
static void on_trackbar2(int alpha_slider2, void*);
static void on_trackbar3(int alpha_slider3, void*);

static void on_trackbar02(int alpha_slider02, void*);
static void on_trackbar12(int alpha_slider12, void*);
static void on_trackbar22(int alpha_slider22, void*);
static void on_trackbar32(int alpha_slider32, void*);

static void on_trackbar03(int alpha_slider02, void*);
static void on_trackbar13(int alpha_slider12, void*);
static void on_trackbar23(int alpha_slider22, void*);
static void on_trackbar33(int alpha_slider32, void*);


void change_src_pic();

void mouseEvent(int evt, int x, int y, int flags, void* param)
{
    if(evt == EVENT_MBUTTONDOWN)
    {
        write();
        change_src_pic();
    }
}

int main()
{
    //Read in picture list
    ifstream datei("bilder.txt");
    string zeile;
    int n = 0;
    while (getline(datei, zeile)) {
        //cout << zeile << endl;
        stringstream zeilenpuffer(zeile);
        string name;
        zeilenpuffer >> name;
        pictures[n] = name;
        n++;
    }

    src = imread("Bilder/"+pictures[0], IMREAD_GRAYSCALE);

    //Create Trackbars
    //imshow("Original", src);
    Mat img = src.clone();
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);

    //Trackbar 0
    int alpha_slider = coefficients[0];
    int alpha_slider_max = IMAGE_WIDTH;
    createTrackbar("d", "Draw", &alpha_slider, alpha_slider_max, on_trackbar);
    on_trackbar(alpha_slider, 0);

    //Trackbar1
    int alpha_slider1;
    if (coefficients[1] < 0) {
        alpha_slider1 = 100+coefficients[1] * 1000;
    }
    else {
        alpha_slider1 = coefficients[1] * 1000 + 100;
    }
    int alpha_slider1_max = 200;
    createTrackbar("c", "Draw", &alpha_slider1, alpha_slider1_max, on_trackbar1);
    on_trackbar1(alpha_slider1, 0);

    //Trackbar2
    int alpha_slider2;
    if (coefficients[2] < 0) {
        alpha_slider2 = 100+int(coefficients[2] * 10000);
    }
    else {
        alpha_slider2 = int(coefficients[2] * 10000) + 100;
    }
    int alpha_slider2_max = 200;
    createTrackbar("b", "Draw", &alpha_slider2, alpha_slider2_max, on_trackbar2);
    on_trackbar2(alpha_slider2, 0);

    //Trackbar3
    int alpha_slider3;
    if (coefficients[3] < 0) {
        alpha_slider3 = 100+int(coefficients[3] * 1000000);
    }
    else {
        alpha_slider3 = int(coefficients[3] * 1000000) + 100;
    }
    int alpha_slider3_max = 200;
    createTrackbar("a", "Draw", &alpha_slider3, alpha_slider3_max, on_trackbar3);
    on_trackbar3(alpha_slider3, 0);
    //img = drawLines(img, coefficients, coefficients2, coefficients3);

    //Trackbar 02
    int alpha_slider02 = coefficients2[0];
    int alpha_slider02_max = IMAGE_WIDTH;
    createTrackbar("d2", "Draw", &alpha_slider02, alpha_slider02_max, on_trackbar02);
    on_trackbar02(alpha_slider02, 0);

    //Trackbar12
    int alpha_slider12;
    if (coefficients2[1] < 0) {
        alpha_slider12 = 100+coefficients2[1] * 1000;
    }
    else {
        alpha_slider12 = coefficients2[1] * 1000 + 100;
    }
    int alpha_slider12_max = 200;
    createTrackbar("c2", "Draw", &alpha_slider12, alpha_slider12_max, on_trackbar12);
    on_trackbar12(alpha_slider12, 0);

    //Trackbar22
    int alpha_slider22;
    if (coefficients2[2] < 0) {
        alpha_slider22 = 100+int(coefficients2[2] * 10000);
    }
    else {
        alpha_slider22 = int(coefficients2[2] * 10000) + 100;
    }
    int alpha_slider22_max = 200;
    createTrackbar("b2", "Draw", &alpha_slider22, alpha_slider22_max, on_trackbar22);
    on_trackbar22(alpha_slider22, 0);

    //Trackbar32
    int alpha_slider32;
    if (coefficients2[3] < 0) {
        alpha_slider32 = 100+int(coefficients2[3] * 1000000);
    }
    else {
        alpha_slider32 = int(coefficients2[3] * 1000000) + 100;
    }
    int alpha_slider32_max = 200;
    createTrackbar("a2", "Draw", &alpha_slider32, alpha_slider32_max, on_trackbar32);
    on_trackbar32(alpha_slider32, 0);

    //img = drawLines(img, coefficients, coefficients2, coefficients3);

    //Trackbar 03
    int alpha_slider03 = coefficients3[0];
    int alpha_slider03_max = IMAGE_WIDTH;
    createTrackbar("d3", "Draw", &alpha_slider03, alpha_slider03_max, on_trackbar03);
    on_trackbar03(alpha_slider03, 0);

    //Trackbar13
    int alpha_slider13;
    if (coefficients3[1] < 0) {
        alpha_slider13 = 100 + coefficients3[1] * 1000;
    }
    else {
        alpha_slider13 = coefficients3[1] * 1000 + 100;
    }
    int alpha_slider13_max = 200;
    createTrackbar("c3", "Draw", &alpha_slider13, alpha_slider13_max, on_trackbar13);
    on_trackbar13(alpha_slider13, 0);

    //Trackbar23
    int alpha_slider23;
    if (coefficients3[2] < 0) {
        alpha_slider23 = 100 + int(coefficients3[2] * 10000);
    }
    else {
        alpha_slider23 = int(coefficients3[2] * 10000) + 100;
    }
    int alpha_slider23_max = 200;
    createTrackbar("b3", "Draw", &alpha_slider23, alpha_slider23_max, on_trackbar23);
    on_trackbar23(alpha_slider23, 0);

    //Trackbar33
    int alpha_slider33;
    if (coefficients3[3] < 0) {
        alpha_slider33 = 100 + int(coefficients3[3] * 1000000);
    }
    else {
        alpha_slider33 = int(coefficients3[3] * 1000000) + 100;
    }
    int alpha_slider33_max = 200;
    createTrackbar("a3", "Draw", &alpha_slider33, alpha_slider33_max, on_trackbar33);
    on_trackbar33(alpha_slider33, 0);

    img = drawLines(img, coefficients, coefficients2, coefficients3);

    setMouseCallback("Draw", mouseEvent, NULL);

   
    waitKey(0);
    return 0;
}

void change_src_pic() {
    a++;
    src = imread("Bilder/" + pictures[a], IMREAD_GRAYSCALE);
    Mat img = src.clone();
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
    
}

Mat drawLines(Mat img, double coefficients[], double coefficients2[], double coefficients3[]) {
    for (int X = 0; X < IMAGE_HEIGHT; X++) {
        int Y = int(coefficients[3] * X * X * X + coefficients[2] * X * X + coefficients[1] * X + coefficients[0]);
        if (Y < IMAGE_WIDTH-2 && Y >= 0) {
            img.at<uchar>(X, Y) = 255;
            //cout << X << ", " << Y << endl;
            img.at<uchar>(X, Y+1) = 255;
            img.at<uchar>(X, Y + 2) = 255;
        }
    }
    for (int X2 = 0; X2 < IMAGE_HEIGHT; X2++) {
        int Y2 = int(coefficients2[3] * X2 * X2 * X2 + coefficients2[2] * X2 * X2 + coefficients2[1] * X2 + coefficients2[0]);
        if (Y2 < IMAGE_WIDTH - 2 && Y2 >= 0) {
            img.at<uchar>(X2, Y2) = 255;
            //cout << X << ", " << Y2 << endl;
            img.at<uchar>(X2, Y2 + 1) = 255;
            img.at<uchar>(X2, Y2 + 2) = 255;
        }
    }
    for (int X3 = 0; X3 < IMAGE_HEIGHT; X3++) {
        int Y3 = int(coefficients3[3] * X3 * X3 * X3 + coefficients3[2] * X3 * X3 + coefficients3[1] * X3 + coefficients3[0]);
        if (Y3 < IMAGE_WIDTH - 2 && Y3 >= 0) {
            img.at<uchar>(X3, Y3) = 255;
            //cout << X << ", " << Y2 << endl;
            img.at<uchar>(X3, Y3 + 1) = 255;
            img.at<uchar>(X3, Y3 + 2) = 255;
        }
    }
    return img;
}

void write() {
    fstream myfile;
    myfile.open(PATH, ios::app);
    myfile << pictures[a] << " " << coefficients[0] << " " << coefficients[1] << " " << coefficients[2] << " " << coefficients[3] << " ";
    myfile << " " << coefficients2[0] << " " << coefficients2[1] << " " << coefficients2[2] << " " << coefficients2[3] << " ";
    myfile << " " << coefficients3[0] << " " << coefficients3[1] << " " << coefficients3[2] << " " << coefficients3[3] << "\n";
    myfile.close();
}


void readfile() {
    cout << "function called" << endl;
    ifstream datei("example.txt");
    string zeile;
    while (getline(datei, zeile)) {
        //cout << zeile << endl;
        stringstream zeilenpuffer(zeile);
        string name;
        double a, b, c, d;
        zeilenpuffer >> name >> a >> b >> c >> d;
        cout << name << " " << a << " " << b << " " << c << " " << d <<endl;
    }  
}

static void on_trackbar(int alpha_slider, void*)
{
    Mat img = src.clone();
    coefficients[0] = alpha_slider;
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar1(int alpha_slider1, void*)
{
    Mat img = src.clone();
    if (alpha_slider1 < 100) {
        coefficients[1] = -(100-alpha_slider1) / double(1000);
    }
    else {
        coefficients[1] = (alpha_slider1 - 100) / double(1000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar2(int alpha_slider2, void*)
{
    Mat img = src.clone();
    if (alpha_slider2 < 100) {
        coefficients[2] = -(100 -alpha_slider2) / double(10000);
    }
    else {
        coefficients[2] = (alpha_slider2 - 100) / double(10000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar3(int alpha_slider3, void*)
{
    Mat img = src.clone();
    if (alpha_slider3 < 100) {
        coefficients[3] = -(100 -alpha_slider3) / double(1000000);
    }
    else {
        coefficients[3] = (alpha_slider3 - 100) / double(1000000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar02(int alpha_slider02, void*)
{
    Mat img = src.clone();
    coefficients2[0] = alpha_slider02;
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar12(int alpha_slider12, void*)
{
    Mat img = src.clone();
    if (alpha_slider12 < 100) {
        coefficients2[1] = -(100 -alpha_slider12) / double(1000);
    }
    else {
        coefficients2[1] = (alpha_slider12 - 100) / double(1000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar22(int alpha_slider22, void*)
{
    Mat img = src.clone();
    if (alpha_slider22 < 100) {
        coefficients2[2] = -(100 -alpha_slider22) / double(10000);
    }
    else {
        coefficients2[2] = (alpha_slider22 - 100) / double(10000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar32(int alpha_slider32, void*)
{
    Mat img = src.clone();
    if (alpha_slider32 < 100) {
        coefficients2[3] = -(100 -alpha_slider32) / double(1000000);
    }
    else {
        coefficients2[3] = (alpha_slider32 - 100) / double(1000000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar03(int alpha_slider03, void*)
{
    Mat img = src.clone();
    coefficients3[0] = alpha_slider03;
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar13(int alpha_slider13, void*)
{
    Mat img = src.clone();
    if (alpha_slider13 < 100) {
        coefficients3[1] = -(100 - alpha_slider13) / double(1000);
    }
    else {
        coefficients3[1] = (alpha_slider13 - 100) / double(1000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar23(int alpha_slider23, void*)
{
    Mat img = src.clone();
    if (alpha_slider23 < 100) {
        coefficients3[2] = -(100 - alpha_slider23) / double(10000);
    }
    else {
        coefficients3[2] = (alpha_slider23 - 100) / double(10000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}

static void on_trackbar33(int alpha_slider33, void*)
{
    Mat img = src.clone();
    if (alpha_slider33 < 100) {
        coefficients3[3] = -(100 - alpha_slider33) / double(1000000);
    }
    else {
        coefficients3[3] = (alpha_slider33 - 100) / double(1000000);
    }
    img = drawLines(img, coefficients, coefficients2, coefficients3);
    imshow("Draw", img);
}