import os

file = open("Test/bilder.txt","w") 

for pic in os.listdir("Test\Bilder"):
    if pic.endswith(".jpg"):
        print(pic)
        file.write(pic+"\n")
file.close