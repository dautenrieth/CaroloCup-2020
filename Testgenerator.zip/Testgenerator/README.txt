READ ME:

Dieses Programm dient zur Erstellung von Testdaten f�r den Carolo Cup. In diesem Programm k�nnen die Fahrbahnbegrenzungen angepasst und f�r die entsprechenden Bilder gespeichert werden.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
VERWENDUNG DES PROGRAMMS:
1. Speichern der zu bearbeitenden Bilder in den Bilder-Ordner (Testgenerator/Test/Bilder)
2. Anpassen der Bilder.txt (Testgenerator/Test/Bilder.txt). L�schen des Inhalts und Ausf�hren des Python Programms writepicnames.py. Dieses speichert die Namen aller zur Verf�gung stehenden Bilder in die Datei.
3. L�schen/Leeren der param.txt Datei (Testgenerator/Test/param.txt). In diese Datei werden die Parameter zusammen mit den Bildpfaden gespeichert.
4. Anzahl der Bilder im Programmcode �ndern (const int NUMBER_OF_PICTURES). (Kann auch auf eine deutlich h�here Zahl gesetzt werden, dann wird das Programm mit einem Fehler beendet. Dies beeinflusst allerdings
	nicht die gespeicherte Datei
5. Starten des Programms
	I. Einstellen der Parameter mithilfe der Spurleiste
	II. Zum Speichern des Bildes das Mausrad dr�cken -> Automatischer Wechsel zum n�chsten Bild

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
STRUKTUR DER DATEIEN:

bilder.txt:
	scene00001.jpg
	scene00018.jpg
	scene00035.jpg
	scene00052.jpg
	-> Auflistung von Bilderbenennung mit Dateiendungen. Ein Eintrag pro Zeile.

param.txt
	scene00001.jpg 555 0.01 0.0004 -3e-06  612 0.044 0.0002 -2e-06  667 0.01 0.0005 -2e-06
	    ^		^    ^     ^      ^	^     ^     ^      ^     ^    ^     ^      ^
	    |		|    |     |      |     |     |     |      |     |    |     |      |
	   Name		Parameter Funktion 1  | Parameter Funktion 2  | Parameter Funktion 3
	Ein Eintrag pro Zeile

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PYTHON HILFSPROGRAMME

renamepics.py:
	Wird verwendet um die Namen der Bilder zu ver�ndern. Dies kann notwendig sein, wenn unterschiedliche extrahierte Bilder den gleichen Namen haben. Das Programm h�ngt allen Bildern in dem Ordner eine 2 an.

writepicnames.py:
	Dieses Programm erstellt automatisch eine Liste mit allen Bildern in dem entsprechenden Ordner. Notwendig wenn man nicht alle Bildernamen von Hand schreiben will.